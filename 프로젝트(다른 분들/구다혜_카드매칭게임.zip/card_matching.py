from turtle import *  #turtle 모듈을 불러오면서 입력 생략
import random
import time


#기본 환경 설정
bgcolor("white") 
setup(700, 700) 
up() 
ht() 
goto(0, 280) #제목 위치
write("카드 매칭 게임", False, "center", ("", 30, "bold"))

    
  
#터틀 객체 생성
turtles = []
pos_x = [-210, -70, 70, 210]
pos_y = [-250, -110, 30, 170]

for x in range(4): 
    for y in range(4):
        new_turtle = Turtle()
        new_turtle.up()
        new_turtle.color("white") 
        new_turtle.speed(0)
        new_turtle.goto(pos_x[x], pos_y[y])
        turtles.append(new_turtle)

default_img = "Images/default_img.gif" #기본 이미지 가져오기
addshape(default_img)

img_list = [] #나머지 이미지 가져오기
for i in range(8):
    img = f"Images/img{i}.gif"
    addshape(img)
    img_list.append(img)
    img_list.append(img) #동일한 이미지 두번씩 추가


random.shuffle(img_list) #랜덤으로 이미지 배치
for i in range(16):
    turtles[i].shape(img_list[i])

time.sleep(3) #이미지 보여줄 시간

for i in range(16):
    turtles[i].shape(default_img) #이미지 다시 가리기




#클릭한 카드 찾아오기
def find_card(x, y): 
    min_idx = 0
    min_dis = 100
    
    for i in range(16):
        distance = turtles[i].distance(x,y)
        if distance < min_dis:
            min_dis = distance
            min_idx = i
    return min_idx




click_num = 0 #클릭 횟수(2회마다 정답체크)
score = 0 #점수
attempt = 0 #시도 횟수
first_pick = "" #첫번째 클릭한 이미지
second_pick = "" #두번째 클릭한 이미지

#게임 내용
def play(x, y):
    global click_num
    global score
    global attempt
    global first_pick
    global second_pick

    if attempt == 12: 
        result("Game Over")
    else:
        click_num += 1
        card_idx = find_card(x, y)
        turtles[card_idx].shape(img_list[card_idx]) #클릭한 이미지 보여주기
        
        if click_num == 1:
            first_pick = card_idx
        elif click_num == 2:
            second_pick = card_idx
            click_num = 0 #초기화
            attempt += 1
            if img_list[first_pick] == img_list[second_pick]:
                score += 1
                score_update("정답")
                if score == 8:
                    result("성공")  
            else:
                score_update("오답")
                time.sleep(0.3) #카드 뒤집어지기전 적절한 시간지연
                turtles[first_pick].shape(default_img)
                turtles[second_pick].shape(default_img)



#점수 객체 생성
score_pen = Turtle()
score_pen.up()
score_pen.ht()
score_pen.goto(0, 230)


#정답 여부
def score_update(m): 
    score_pen.clear()
    score_pen.write(f"{score}회 성공 / 남은 기회 {12-attempt}번", False,  "center", ("", 15))


#게임 결과
def result(m): 
    goto(0, -60)
    write(m, False, "center", ("", 30, "bold"))


onscreenclick(play) #화면 클릭했을때 함수 실행
done() #창이 바로 닫히지 않게

